/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity.guru;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Keen
 */
@Entity
@Table(name = "wisewords")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Wisewords.findAll", query = "SELECT w FROM Wisewords w")
    , @NamedQuery(name = "Wisewords.findById", query = "SELECT w FROM Wisewords w WHERE w.id = :id")
    , @NamedQuery(name = "Wisewords.findByGuruword", query = "SELECT w FROM Wisewords w WHERE w.guruword = :guruword")})
public class Wisewords implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "guruword")
    private String guruword;

    public Wisewords() {
    }

    public Wisewords(Integer id) {
        this.id = id;
    }

    public Wisewords(Integer id, String guruword) {
        this.id = id;
        this.guruword = guruword;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getGuruword() {
        return guruword;
    }

    public void setGuruword(String guruword) {
        this.guruword = guruword;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Wisewords)) {
            return false;
        }
        Wisewords other = (Wisewords) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return guruword;
    }
    
}
