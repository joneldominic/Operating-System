/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myguruserver;

import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

/**
 *
 * @author Keen
 */
public class MyGuruServer {
    
    private static final int guruPort = 12345;
    
    public static void main(String[] args){
        MyGuruServiceImpl guruServiceImpl = null;
        
        try{
            guruServiceImpl = new MyGuruServiceImpl();
        } catch(RemoteException re){
            System.out.println("Oops! Unable to start up MyGuruService server");
            System.out.println(re);
            System.exit(1);
        }
        
        String bindName = "TheGuruService";
        Registry rmiNamingService = null;
        
        try{
            rmiNamingService = LocateRegistry.createRegistry(guruPort);
        } catch(RemoteException re){
            System.out.println("Coudn't create rmi registry!");
            System.out.println(re);
            System.exit(1);
        }
        
        System.out.println("About to bind " + bindName );
        
        try{
            rmiNamingService.rebind(bindName, guruServiceImpl);
        } catch(Exception e){
            System.out.println(e);
            System.exit(1);
        }
        
        System.out.println("MyGuruService server believed to be running");
        System.out.println("Service name: " + bindName);
        System.out.println("Rmiregistry port: " + guruPort);
    }
}
