/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myguruserver;

import entity.guru.Wisewords;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import service.guru.MyGuruService;

/**
 *
 * @author Keen
 */
public class MyGuruServiceImpl extends UnicastRemoteObject implements MyGuruService {
    
    private EntityManagerFactory emf;
    private EntityManager em;
    
    public MyGuruServiceImpl() throws RemoteException{
        try{
            emf = Persistence.createEntityManagerFactory("MyGuruServerPU");
            em = emf.createEntityManager();
        } catch(Exception e){
            System.out.println(e);
            System.exit(1);
        }
    }
    
    @Override
    public List<Wisewords> enlightenMe() throws RemoteException {
        Query query = em.createNamedQuery("Wisewords.findAll");
        List<Wisewords> wiseWords = (List<Wisewords>)query.getResultList();
        em.clear();
        
        return wiseWords;        
    }
    
}
