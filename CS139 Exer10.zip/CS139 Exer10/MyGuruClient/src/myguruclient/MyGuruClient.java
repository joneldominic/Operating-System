/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myguruclient;

import entity.guru.Wisewords;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import service.guru.MyGuruService;

/**
 *
 * @author Keen
 */
public class MyGuruClient {
    
    private static final String hostName = "localhost";
    private static final String GuruServicePort = "12345";
    private static final String principal = "TheGuruService";
    
    private static Random randGen;
    private static int wordSize;
    
    public static void main(String[] args){
        String serviceName = "rmi://" + hostName + ":" + GuruServicePort + "/" + principal;
        String choice;
        Scanner input = new Scanner(System.in);
        
        randGen = new Random();
        
        System.out.println("Contacting service " + serviceName);
        
        MyGuruService myGuruService = null;
        
        try {
            myGuruService = (MyGuruService) Naming.lookup(serviceName);
        } catch(MalformedURLException | NotBoundException | RemoteException mfure) {
            System.out.println(mfure);
            System.exit(1);
        }
        
        try {
            System.out.println("WISE WORDS");
            List<Wisewords> theWords = myGuruService.enlightenMe();
            wordSize = theWords.size();
            
            do {
                System.out.println("The guru says \"" + theWords.get(show()) + "\"");
                System.out.print("Do you want to be enlighten the more (Y|N)?");
                choice = input.nextLine();
            } while(choice.equals("Y"));
            
        } catch(RemoteException re) {
            System.out.println(re);
            System.exit(1);
        }
    }
    
    private static int show() {
        int nextInLine = randGen.nextInt(wordSize);
        return nextInLine;
    }
}
