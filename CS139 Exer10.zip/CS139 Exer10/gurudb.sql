-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 30, 2018 at 08:52 AM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gurudb`
--

-- --------------------------------------------------------

--
-- Table structure for table `wisewords`
--

CREATE TABLE `wisewords` (
  `id` int(10) UNSIGNED NOT NULL,
  `guruword` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wisewords`
--

INSERT INTO `wisewords` (`id`, `guruword`) VALUES
(1, 'The trouble with doing something right the first time is that nobody appreciates how difficult it was. '),
(3, 'The only people who find what they are looking for are those who are looking for errors. '),
(5, 'Let no man in the world live in delusion. Without a Guru none can cross over to the other shore. '),
(7, 'There is but One God. His name is Truth; He is the Creator. He fears none; he is without hate. He never dies; He is beyond the cycle of births and death. He is self-illuminated. He is realized by the kindness of the True Guru. He was True in the beginning; He was True when the ages commenced and has ever been True. He is also True now.'),
(8, 'I hang out with my guru in my heart. And I love every thing in the universe. That''s all I do all day.');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `wisewords`
--
ALTER TABLE `wisewords`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `wisewords`
--
ALTER TABLE `wisewords`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
