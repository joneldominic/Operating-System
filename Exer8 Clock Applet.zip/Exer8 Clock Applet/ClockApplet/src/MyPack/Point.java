/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MyPack;

/**
 *
 * @author Tapang
 */
public class Point {
    int X;
    int Y;
    
    public Point(int x, int y){
        X = x;
        Y = y;
    }
    
    public void setXCoord(int x){
        X = x;
    }
    
    public void setYCoord(int y){
        Y = y;
    }
    
    public int getXCoord(){
        return X;
    }
    
    public int getYCoord(){
        return Y;
    }
}
