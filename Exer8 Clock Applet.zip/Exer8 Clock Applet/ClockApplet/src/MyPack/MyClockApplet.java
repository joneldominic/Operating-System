/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MyPack;

import java.applet.*;
import java.awt.*;
import java.util.Date;

/**
 *
 * @author Tapang
 */
public class MyClockApplet extends Applet implements Runnable{
    
    private Thread clockThread;
    private Date now = new Date();
    private int width;
    private int height; 
    private int diameter;
    private int radius;
    private int cx;
    private int cy;
    private int HH, MM, SS;
    
    /**
     * Initialization method that will be called after the applet is loaded into
     * the browser.
     */
     
    public void init() {
        // Determine the size of the canvas as defined in the html file
        width = getSize().width;
        height = getSize().height; 
        
        // Determine the diameter and radius of the clock
        diameter = (width < height)? width : height;
        radius = diameter/2;
        
        // Determine the center of the clock (circle)
        cx = diameter/2;
        cy = diameter/2;
        
        HH = 0;
        MM = 0;
        SS = 0;
    }
    
    public void run() {
        while(true) {
            try{
               Thread.sleep(1000);
            } catch(InterruptedException e) { }
            init();
            repaint();
       }
    }
    
    public void start() {
        if ( clockThread == null ) { 
           clockThread= new Thread(this);
          clockThread.start();
        } else clockThread.resume();
    }
  
    public void stop() {      
        if (clockThread != null)
            clockThread.suspend();
    }
  
    public void destroy() {
        if (clockThread != null) {
            clockThread.stop();           
            clockThread= null;
        }
    }
    
    public void paint(Graphics g) {
        super.paint(g);
        Graphics2D gd = (Graphics2D) g;
       
        
        // Drawing the Background Circle
        gd.setColor(Color.LIGHT_GRAY);
        gd.fillOval((int)(.85*radius),2, diameter-2, diameter-2);
        
        // Drawing the Outer Circle
        gd.setStroke(new BasicStroke(2));
        gd.setColor(Color.black);
        gd.drawOval((int)(.85*radius), 2, diameter-2, diameter-2);
        
        // Display Hour Spots
        gd.setStroke(new BasicStroke(4));
        drawHourSpot(gd);
        
        // Displaying Digital Time
        gd.setFont(new Font("TimesRoman", Font.PLAIN, (int)(20*(0.009*radius))));
        gd.setColor(Color.black);
        now = new Date();
        gd.drawString(now.getHours() + ":" + now.getMinutes() + ":" + now.getSeconds(), (int)(radius+(.60*radius)), (int)(cy-(0.3*(radius))));
        
        String strTime = now.toString();
        strTime = strTime.substring(11, 20);
        HH = Integer.parseInt(strTime.substring(0,2));
        MM = Integer.parseInt(strTime.substring(3,5));
        SS = Integer.parseInt(strTime.substring(6,8));
        
        // Draw hands
        drawSecHand(gd);
        drawMinHand(gd);
        drawHrHand(gd);
        
        // Draw Center Point
        gd.setColor(Color.black);
        gd.fillOval((int)(radius+(.84*radius)), cx-6, 10, 10);
    }
    
    public void drawSecHand(Graphics2D gd){
        ClockHand sHand; 
        sHand = new ClockHand(Color.RED, new BasicStroke(1));
        sHand.setRadian(SS, 60);
        sHand.setCenter((int)(radius+(.85*radius)), cy, (int)(radius-(0.10*radius)));
        sHand.DrawHand(gd);
    }
    
    public void drawMinHand(Graphics2D gd){
        ClockHand mHand; 
        mHand = new ClockHand(Color.BLUE, new BasicStroke(2));
        mHand.setRadian(MM, 60);
        mHand.setCenter((int)(radius+(.85*radius)), cy, (int)(radius-(0.40*radius)));
        mHand.DrawHand(gd);
    }
    
    public void drawHrHand(Graphics2D gd){
        ClockHand hHand; 
        hHand = new ClockHand(Color.GREEN, new BasicStroke(3));
        hHand.setRadian(HH, 12);
        hHand.setCenter((int)(radius+(.85*radius)), cy, (int)(radius-(0.60*radius)));
        hHand.DrawHand(gd);
    }
    
    public void drawHourSpot(Graphics2D gd){
        int x1 = 0, y1 = 0, x2 = 0, y2 = 0;
        int r1 = cy-3;
        int r2 = cy - 10;
        double radian = 0;
        double[] arrPos = new double[] {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12 };
        
        for(int i=0; i<12; i++){

            radian = (arrPos[i] * (360 / 12)) * Math.PI / 180;
            x1 = (int)((cx + r1 * Math.sin(radian))+(.85*radius));
            y1 = (int)(cy - r1 * Math.cos(radian));
            x2 = (int)((cx + r2 * Math.sin(radian))+(.85*radius));
            y2 = (int)(cy - r2 * Math.cos(radian));
            gd.drawLine(x1, y1, x2, y2);
        }
    }
    
  
}