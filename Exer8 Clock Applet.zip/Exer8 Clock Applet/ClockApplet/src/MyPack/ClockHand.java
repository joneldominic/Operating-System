/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MyPack;

import java.awt.*;
import java.awt.Graphics;
import java.awt.Graphics2D;
/**
 *
 * @author Tapang
 */
public class ClockHand{
    
    private Point p1 = new Point(0,0);
    private Point p2 = new Point(0,0);
    private int radius = 0;
    private double radian = 0.0;
    private Color handColor = Color.BLACK;
    private BasicStroke bStroke;
    
    public ClockHand(Color hColor, BasicStroke stroke){
        handColor = hColor;
        bStroke = stroke;
    }
    
    public void setRadian(int pos, int divisor){
        radian = (pos * (360 / divisor)) * Math.PI / 180;
    }
    
    public void setEndPoint()
    {
        double dx1 = (double)p1.getXCoord() + radius * Math.sin(radian);
        double dy1 = (double)p1.getYCoord() - radius * Math.cos(radian);
        p2.X = (int)dx1;
        p2.Y = (int)dy1;
    }
    
    public void setCenter(int x1, int y1, int r)
    {
        p1.X = x1;
        p1.Y = y1;
        radius = r;
    }
    
    public void DrawHand(Graphics2D gTwoD){
        gTwoD.setStroke(bStroke);
        gTwoD.setColor(handColor);
        setEndPoint();
        gTwoD.drawLine(p1.X, p1.Y, p2.X, p2.Y);
    }
    
    //Following codes are getters for private elements:
    public Point getPoint1()
    {
        Point pt = new Point(p1.X, p1.Y);
        return pt;
    }


    public Point getPoint2()
    {
        Point pt = new Point(p2.X, p2.Y);
        return pt;
    }

    public int getRadius()
    {
        return radius;
    }
    
    public double getRadian()
    {
        return radian;
    }
}
