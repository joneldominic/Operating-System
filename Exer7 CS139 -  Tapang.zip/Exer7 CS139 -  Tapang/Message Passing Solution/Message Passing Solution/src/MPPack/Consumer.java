/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MPPack;

/**
 *
 * @author Keen
 */
import static java.lang.Thread.sleep;
import java.util.*;
class Consumer extends Thread {
    
    private MessageQueue mbox;
    
    public Consumer(MessageQueue m) {
        mbox = m;
    }
    
    private int getSleepTime() { 
        int time = (int) (MessageQueue.NAP_TIME * Math.random() );
        return (time==0) ? getSleepTime() : time;  //Prevent from getting a value of 0
    }
    
    public void run() {
        Date message;
        
        while(true){
            int sleeptime = getSleepTime();
            mbox.consumerBar(sleeptime); 
            mbox.setConsumerStatus("STATUS: Sleeping...");
            System.out.println("Consumer is sleeping for " + sleeptime + " second(s)");
            
            try {
                sleep(sleeptime*1000); 
            } catch(InterruptedException e) {}
            
            //consume an item from the buffer
            message = (Date) mbox.receive();
            
            if (message != null){
                mbox.setConsumerStatus("STATUS: Consuming...");
                System.out.println("Consumer consumes [" + message + "]: Buffer size = " + mbox.getBuffContent());
            }
            else{
                mbox.setConsumerStatus("STATUS: Waiting...");
                System.out.println("Consumer is waiting: Buffer is Empty");
            }
            
            System.out.println("");
        }
    }
}
            
    



