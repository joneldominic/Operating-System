/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MPPack;

/**
 *
 * @author Keen
 */
import static java.lang.Thread.sleep;
import java.util.*;
class Producer extends Thread {
    
    private MessageQueue mbox;
    
    public Producer(MessageQueue m) {
        mbox = m;
    }
    
    private int getSleepTime() { 
        int time = (int) (MessageQueue.NAP_TIME * Math.random() );
        return (time==0) ? getSleepTime() : time;  //Prevent from getting a value of 0
    }
     
    public void run() {
        Date message;

        while(true) {
            int sleeptime =  getSleepTime();
            mbox.producerBar(sleeptime); 
            mbox.setProducerStatus("STATUS: Sleeping...");
            System.out.println("Producer is sleeping for " + sleeptime + " second(s)");
            
            try {
                sleep(sleeptime*1000); 
            }
            catch(InterruptedException e) {}
            
            if(mbox.getBuffContent() == mbox.getBuffMaxHold()){
                mbox.setProducerStatus("STATUS: Waiting...");
                System.out.println("Producer waiting: Buffer is Full");
            }
            else{
                mbox.setProducerStatus("STATUS: Producing...");
                message = new Date();
                mbox.send(message);
                System.out.println("Producer produces [" + message + "]: Buffer size = " + mbox.getBuffContent());
            }
            
            System.out.println("");
        }
    }
}
