/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SMPack;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimerTask;
import javax.swing.Timer;

/**
 *
 * @author Keen
 */
public class BoundedBuffer extends javax.swing.JFrame {

    private final Producer producerThread;
    private final Consumer consumerThread ;
    public static final int NAP_TIME = 8;
    private static final int BUFFER_SIZE = 3;
    private volatile int count;
    private final DecimalFormat df = new DecimalFormat("#.###");
    private int in; // points to the next free position in thebuffer
    private int out; // points to the next full position in thebuffer
    private Object[] buffer;

    public BoundedBuffer() {
        initComponents();
        setLocationRelativeTo(this);
        setResizable(false);
        startClock();
        
        // Buffer is initially empty
        count = 0;
        in = 0;
        out = 0;
        buffer = new Object[BUFFER_SIZE];
        
        // Content of Server class is transfered in here------------------------
        producerThread = new Producer(this);
        consumerThread = new Consumer(this);
        producerThread.start();
        consumerThread.start();
        //----------------------------------------------------------------------
    }
    
    // Display actual time in the Frame Title
    private void startClock(){
        Timer timer = new Timer(500, (ActionEvent e) -> {
            setTitle(new SimpleDateFormat("MM/dd/yyyy (HH:mm:ss)").format(new Date()));
        });
        timer.setRepeats(true);
        timer.setCoalesce(true);
        timer.setInitialDelay(0);
        timer.start();
    }
    
    // Producer calls this method
    public void enter(Object item) {
        while (count == BUFFER_SIZE);// do nothing
        //add an item to the buffer
        ++count;
        buffer[in] = item;
        in = (in + 1) % BUFFER_SIZE;
        if (count == BUFFER_SIZE){
            jLabel_BufferContent.setText("BUFFER CONTENT: " +  count);
        }
        else{
            jLabel_BufferContent.setText("BUFFER CONTENT: " +  count);
        }
        UpdateBufferModel(count); //Update the graphical representaion of buffer
    }
    
    // Consumer calls this method
    public Object remove() {
        Object item;
        while (count == 0); // do nothing
        // remove an item from the buffer
        --count;
        item = buffer[out];
        out = (out + 1) % BUFFER_SIZE;
        if (count == 0){
            jLabel_BufferContent.setText("BUFFER CONTENT: " +  count);
        }
        else{
            jLabel_BufferContent.setText("BUFFER CONTENT: " +  count);
        }
        UpdateBufferModel(count); //Update the graphical representaion of buffer
        return item;
    }
    
    // User-defined setter and getter
    public int getBufferCount(){
        return count;
    }
    
    public int getBuffSize(){
        return BUFFER_SIZE;
    }
    
    public void setProducerStatus(String status){
        jLabel_PStatus.setText(status);
    }
    
    public void setConsumerStatus(String status){
         jLabel_CStatus.setText(status);
    }
       
    public String getCStatus(){
        return jLabel_CStatus.getText();
    }
    
    public String getPStatus(){
        return jLabel_PStatus.getText();
    }
    //--------------------------------------------------------------------------
   
    // Loading bar for producer
    protected void producerBar(int wait){
        jProgressBar_Producer.setMinimum(0);
        jProgressBar_Producer.setMaximum(wait*1000);
        
        jLabel_BufferContent.setText("BUFFER CONTENT: " + count);
                
        if(jLabel_PStatus.getText().equals("STATUS: Producing...")){
            try {
                Thread.sleep(300);
            } catch (InterruptedException ex) {}
            jLabel_PStatus.setText("STATUS: Sleeping...");
        }            
        
        final java.util.Timer t = new java.util.Timer();
        t.scheduleAtFixedRate(new TimerTask() {
            int i = wait*1000;
            @Override
            public void run() {
                jProgressBar_Producer.setValue(i);
                jLabel_PSTime.setText("SLEEPING TIME: " + df.format(i/1000.0)+" s");
                i--;
                if(i < 0){ t.cancel(); }
            }
        }, 0, 1);
    }
    
    // Loading bar for consumer
    protected void consumerBar(int wait){
        jProgressBar_Consumer.setMinimum(0);
        jProgressBar_Consumer.setMaximum(wait*1000);
        
        jLabel_BufferContent.setText("BUFFER CONTENT: " + count);
        
        if(jLabel_CStatus.getText().equals("STATUS: Consuming...")){
            try {
                Thread.sleep(300);
            } catch (InterruptedException ex) {}
            jLabel_CStatus.setText("STATUS: Sleeping...");
        }
        
        final java.util.Timer t = new java.util.Timer();
        t.scheduleAtFixedRate(new TimerTask() {
            int i = wait*1000;
            @Override
            public void run() {
                jProgressBar_Consumer.setValue(i);
                jLabel_CSTime.setText("SLEEPING TIME: " + df.format(i/1000.0)+" s");
                i--;
                
                if(i < 0){ t.cancel(); }
            }
        }, 0, 1);
    }
    
    // Responsible for Buffer Visual Representaion
    // Using jPanels
    public void UpdateBufferModel(int size){
        
        jPanel_Element1.setBackground(Color.WHITE);
        jPanel_Element2.setBackground(Color.WHITE);
        jPanel_Element3.setBackground(Color.WHITE);

        switch(size){
            case 1:
                    jPanel_Element1.setBackground(Color.BLACK);
                    jPanel_Element2.setBackground(Color.WHITE);
                    jPanel_Element3.setBackground(Color.WHITE);
                break;
            case 2:
                    jPanel_Element1.setBackground(Color.BLACK);
                    jPanel_Element2.setBackground(Color.BLACK);
                    jPanel_Element3.setBackground(Color.WHITE);
                break;
            case 3:
                    jPanel_Element1.setBackground(Color.BLACK);
                    jPanel_Element2.setBackground(Color.BLACK);
                    jPanel_Element3.setBackground(Color.BLACK);
                break;    
        }
    }
        
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jProgressBar_Producer = new javax.swing.JProgressBar();
        jLabel_PStatus = new javax.swing.JLabel();
        jLabel_PSTime = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel_CSTime = new javax.swing.JLabel();
        jProgressBar_Consumer = new javax.swing.JProgressBar();
        jLabel_CStatus = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jLabel_Title1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jPanel_Element1 = new javax.swing.JPanel();
        jPanel_Element3 = new javax.swing.JPanel();
        jPanel_Element2 = new javax.swing.JPanel();
        jLabel_BufferContent = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel_Title = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();
        jPanel_Element4 = new javax.swing.JPanel();
        jLabel_Title2 = new javax.swing.JLabel();
        jSeparator3 = new javax.swing.JSeparator();
        jSeparator4 = new javax.swing.JSeparator();
        jSeparator5 = new javax.swing.JSeparator();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(java.awt.Color.WHITE);

        jPanel4.setBackground(java.awt.Color.WHITE);

        jProgressBar_Producer.setPreferredSize(new java.awt.Dimension(146, 17));

        jLabel_PStatus.setFont(new java.awt.Font("Century Gothic", 1, 10)); // NOI18N
        jLabel_PStatus.setText("STATUS: ");

        jLabel_PSTime.setFont(new java.awt.Font("Century Gothic", 1, 10)); // NOI18N
        jLabel_PSTime.setText("SLEEPING TIME:");

        jLabel1.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        jLabel1.setText("PRODUCER");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jProgressBar_Producer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel_PSTime))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel_PStatus))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jLabel_PSTime)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jProgressBar_Producer, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel_PStatus)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        jPanel8.setBackground(java.awt.Color.WHITE);

        jLabel2.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        jLabel2.setText("CONSUMER");

        jLabel_CSTime.setFont(new java.awt.Font("Century Gothic", 1, 10)); // NOI18N
        jLabel_CSTime.setText("SLEEPING TIME: ");

        jProgressBar_Consumer.setFont(new java.awt.Font("Century Gothic", 1, 10)); // NOI18N
        jProgressBar_Consumer.setPreferredSize(new java.awt.Dimension(146, 17));

        jLabel_CStatus.setFont(new java.awt.Font("Century Gothic", 1, 10)); // NOI18N
        jLabel_CStatus.setText("STATUS: ");

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jProgressBar_Consumer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel_CSTime)
                    .addComponent(jLabel2)
                    .addComponent(jLabel_CStatus))
                .addContainerGap(30, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel_CSTime)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jProgressBar_Consumer, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel_CStatus)
                .addContainerGap(26, Short.MAX_VALUE))
        );

        jPanel5.setBackground(java.awt.Color.WHITE);

        jLabel_Title1.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        jLabel_Title1.setText("BUFFER");

        jPanel3.setBackground(java.awt.Color.WHITE);
        jPanel3.setBorder(javax.swing.BorderFactory.createCompoundBorder(null, javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, java.awt.Color.BLACK)));

        jPanel_Element1.setBackground(java.awt.Color.WHITE);
        jPanel_Element1.setBorder(javax.swing.BorderFactory.createCompoundBorder(null, javax.swing.BorderFactory.createLineBorder(java.awt.Color.BLACK)));

        javax.swing.GroupLayout jPanel_Element1Layout = new javax.swing.GroupLayout(jPanel_Element1);
        jPanel_Element1.setLayout(jPanel_Element1Layout);
        jPanel_Element1Layout.setHorizontalGroup(
            jPanel_Element1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel_Element1Layout.setVerticalGroup(
            jPanel_Element1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 40, Short.MAX_VALUE)
        );

        jPanel_Element3.setBackground(java.awt.Color.WHITE);
        jPanel_Element3.setBorder(javax.swing.BorderFactory.createCompoundBorder(null, javax.swing.BorderFactory.createLineBorder(java.awt.Color.BLACK)));

        javax.swing.GroupLayout jPanel_Element3Layout = new javax.swing.GroupLayout(jPanel_Element3);
        jPanel_Element3.setLayout(jPanel_Element3Layout);
        jPanel_Element3Layout.setHorizontalGroup(
            jPanel_Element3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel_Element3Layout.setVerticalGroup(
            jPanel_Element3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 40, Short.MAX_VALUE)
        );

        jPanel_Element2.setBackground(java.awt.Color.WHITE);
        jPanel_Element2.setBorder(javax.swing.BorderFactory.createCompoundBorder(null, javax.swing.BorderFactory.createLineBorder(java.awt.Color.BLACK)));

        javax.swing.GroupLayout jPanel_Element2Layout = new javax.swing.GroupLayout(jPanel_Element2);
        jPanel_Element2.setLayout(jPanel_Element2Layout);
        jPanel_Element2Layout.setHorizontalGroup(
            jPanel_Element2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel_Element2Layout.setVerticalGroup(
            jPanel_Element2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 40, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel_Element1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel_Element3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel_Element2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addComponent(jPanel_Element3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel_Element2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel_Element1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12))
        );

        jLabel_BufferContent.setFont(new java.awt.Font("Century Gothic", 1, 12)); // NOI18N
        jLabel_BufferContent.setText("BUFFER CONTENT: 0");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGap(76, 76, 76)
                                .addComponent(jLabel_Title1))
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGap(40, 40, 40)
                                .addComponent(jLabel_BufferContent)))
                        .addGap(0, 42, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel_Title1, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel_BufferContent, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(12, Short.MAX_VALUE))
        );

        jSeparator1.setBackground(Color.BLACK);
        jSeparator1.setBackground(java.awt.Color.BLACK);
        jSeparator1.setForeground(java.awt.Color.BLACK);
        jSeparator1.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N

        jLabel_Title.setFont(new java.awt.Font("Century Gothic", 1, 16)); // NOI18N
        jLabel_Title.setText("Producer - Consumer Problem");

        jSeparator2.setOrientation(javax.swing.SwingConstants.VERTICAL);

        jPanel_Element4.setBackground(java.awt.Color.WHITE);
        jPanel_Element4.setBorder(javax.swing.BorderFactory.createCompoundBorder(null, javax.swing.BorderFactory.createLineBorder(java.awt.Color.BLACK)));

        jLabel_Title2.setFont(new java.awt.Font("Century Gothic", 1, 10)); // NOI18N
        jLabel_Title2.setText("SHARED - MEMORY SOLUTION");

        javax.swing.GroupLayout jPanel_Element4Layout = new javax.swing.GroupLayout(jPanel_Element4);
        jPanel_Element4.setLayout(jPanel_Element4Layout);
        jPanel_Element4Layout.setHorizontalGroup(
            jPanel_Element4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel_Element4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel_Title2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel_Element4Layout.setVerticalGroup(
            jPanel_Element4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel_Element4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel_Title2)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel_Title)
                .addGap(93, 93, 93))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 404, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 11, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jSeparator3)))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel_Element4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator5, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel_Title)
                .addGap(18, 18, 18)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jSeparator2, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 8, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel_Element4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, 8, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jSeparator5, javax.swing.GroupLayout.PREFERRED_SIZE, 8, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(17, 17, 17))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(BoundedBuffer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(BoundedBuffer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(BoundedBuffer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(BoundedBuffer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new BoundedBuffer().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel_BufferContent;
    private javax.swing.JLabel jLabel_CSTime;
    private javax.swing.JLabel jLabel_CStatus;
    private javax.swing.JLabel jLabel_PSTime;
    private javax.swing.JLabel jLabel_PStatus;
    private javax.swing.JLabel jLabel_Title;
    private javax.swing.JLabel jLabel_Title1;
    private javax.swing.JLabel jLabel_Title2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel_Element1;
    private javax.swing.JPanel jPanel_Element2;
    private javax.swing.JPanel jPanel_Element3;
    private javax.swing.JPanel jPanel_Element4;
    private javax.swing.JProgressBar jProgressBar_Consumer;
    private javax.swing.JProgressBar jProgressBar_Producer;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    // End of variables declaration//GEN-END:variables
}
