/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SMPack;

/**
 *
 * @author Keen
 */
import SMPack.BoundedBuffer;
import java.util.*;
public class Consumer extends Thread {
    
    private int getSleepTime() { 
        int time = (int) (BoundedBuffer.NAP_TIME * Math.random() );
        return (time==0) ? getSleepTime() : time;  //Prevent from getting a value of 0
    }
    
    public Consumer(BoundedBuffer b) {
            buffer = b;
    }

    public void run() {
        Date message;
        while(true) {
            int sleeptime = getSleepTime();
            buffer.consumerBar(sleeptime);
            buffer.setConsumerStatus("STATUS: Sleeping...");
            System.out.println("Consumer is sleeping for " + sleeptime + " second(s)");

            try {
                sleep(sleeptime*1000); 
            } catch(InterruptedException e) {}

            if(buffer.getBufferCount() == 0){
                buffer.setConsumerStatus("STATUS: Waiting...");
                System.out.println("Consumer waiting: Buffer is Empty");
            }
            else{
                message = (Date) buffer.remove();
                buffer.setConsumerStatus("STATUS: Consuming...");
                System.out.println("Consumer consumes [" + message + "]: Buffer size = " + buffer.getBufferCount());
            }
            System.out.println("");
        }
    }
    private BoundedBuffer buffer;
}