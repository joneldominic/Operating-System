/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SMPack;

/**
 *
 * @author Keen
 */
import java.util.*;
public class Producer extends Thread  {
    
    public Producer(BoundedBuffer b) {
        buffer = b;
    }
        
    private int getSleepTime() { 
        int time = (int) (BoundedBuffer.NAP_TIME * Math.random() );
        return (time==0) ? getSleepTime() : time;  //Prevent from getting a value of 0
    }
          
    public void run() {
        Date message;
        while(true) {
            int sleeptime = getSleepTime();
            buffer.producerBar(sleeptime);
            buffer.setProducerStatus("STATUS: Sleeping...");
            System.out.println("Producer is sleeping for " + sleeptime + " second(s)");
                   
            try {
                sleep(sleeptime*1000); 
            } catch(InterruptedException e) {}
                    
            if(buffer.getBufferCount() == buffer.getBuffSize()){
                buffer.setProducerStatus("STATUS: Waiting...");
                System.out.println("Producer waiting: Buffer is Full");
            }
            else{
                message = new Date(); //produce an item & enter it into the buffer
                buffer.enter(message);
                buffer.setProducerStatus("STATUS: Producing...");
                System.out.println("Producer produced [" + message + "]: Buffer size = " + buffer.getBufferCount());
            }
            System.out.println("");
        }
    }
    private BoundedBuffer buffer;
}
