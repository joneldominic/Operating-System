/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chatter;

import java.awt.*;
import java.awt.event.* ;
import javax.swing.* ;
import java.io.* ;

/**
 *
 * @author Keen
 */
public class ServerFrame extends JFrame{
    
    JTextField text ;
    TextArea taR, taS;
    JButton bR, bS;
    JScrollPane p1, p2 ;
    ServerLt sl ;
    ObjectOutputStream oos[] ;
    
    public ServerFrame() {
        super("Chat Server");
        setDefaultLookAndFeelDecorated(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
        setSize(450,350);
        setVisible(true);
        getContentPane().setLayout(null);
        JLabel lblPort = new JLabel("Port Number [>1024]");
        getContentPane().add(lblPort);
        text = new JTextField("5000"); // port value 
        getContentPane().add(text);
        taR = new TextArea(); // Receiver 
        taS = new TextArea(); // Sender 
        bS = new JButton("Go"); 
        getContentPane().add(bS);
        bR = new JButton("Start Server");
        getContentPane().add(bR);
        getContentPane().add(taR);
        getContentPane().add(taS);
        lblPort.setBounds(20,20,130,25);
        text.setBounds(150,20,80,25);
        bR.setBounds(250,20,110,25);
        taR.setBounds(20,60,400,180);
        taS.setBounds(20,260,340,50);
        bS.setBounds(370,260,50,50);
        
        /************************************
        * Start Server button
        *************************************/
        oos = new ObjectOutputStream[ServerLt.MAX] ;
        bR.addActionListener(
            new ActionListener(){
                public void actionPerformed(ActionEvent e) {
                    try{
                        int port = Integer.parseInt(text.getText());
                        sl = new ServerLt(port, taR, oos);
                        sl.start();
                    } catch (Exception ex) {
                        System.out.println("Connect Error : " + ex);
                    }
                }
            }
        );
        
        /*************************************
        * Go button
        *************************************/
        bS.addActionListener(
            new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    
                    if (oos == null){
                        return;
                    }
                    
                    try {
                        for (int a=0 ; a < oos.length ;a++) {
                            oos[a].writeObject("Server: " + taS.getText());
                        }
                    } catch (Exception ex) {
                        //System.out.println("Server Go error: " + ex);
                    }
                    taR.append("Server: " + taS.getText() + "\n");
                    taS.setText("");
                }
            }
        );
        validate();
    }
    
    public static void main (String arg[]) {
        new ServerFrame();
    }
    
}
