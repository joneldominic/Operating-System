/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chatter;

import java.net.* ;
import java.awt.* ;
import java.io.* ;
import javax.swing.JOptionPane;

/**
 *
 * @author Keen
 */
public class ServerLt extends Thread {
    
    final static int MAX = 10 ;
    int port ;
    ServerSocket server ;
    Socket incoming ;
    ObjectInputStream ois[] ;
    ObjectOutputStream oos[] ;
    Listener listen[] ;
    TextArea taR,taS ;

    public ServerLt(int port, TextArea taR, ObjectOutputStream oos[]) {
        try {
            this.port = port ;
            server = new ServerSocket(port);
            this.taR = taR ;
            this.taS = taS ;
            ois = new ObjectInputStream[MAX];
            this.oos = oos ;
            listen = new Listener[MAX] ;
        } catch (Exception ex) {
            System.out.println("Error : " + ex);
               JOptionPane.showMessageDialog(null, "Connection Error: " + ex , "Error!", JOptionPane.ERROR_MESSAGE);
        }
    } 
    
    public void run() {
        int cnt = 0 ;
        taR.setText("Waiting for clients... \n");
        while( cnt < MAX) {
            
            try {
                incoming = server.accept(); 
                //taR.append("Client : " + cnt + " connected \n"); 
                taR.append("New Client connected \n");
                ois[cnt] = new ObjectInputStream(incoming.getInputStream()); 
                oos[cnt] = new ObjectOutputStream(incoming.getOutputStream()); 
                oos[cnt].flush(); 
                listen[cnt] = new Listener(taR,ois[cnt],cnt,"Server"); 
                listen[cnt].setAll(oos); 
                listen[cnt].start(); 
                cnt++ ;
                
            } catch (Exception ex) {
                System.out.println("Error : " + ex);
            }
        }
        JOptionPane.showMessageDialog(null, "Max Number of Client Reached", "Error!", JOptionPane.ERROR_MESSAGE);
    }
    
}