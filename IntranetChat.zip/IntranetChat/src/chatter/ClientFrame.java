/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chatter;

import java.awt.*;
import java.awt.event.*; 
import javax.swing.* ;
import java.io.* ;
import java.net.* ;

/**
 *
 * @author Keen
 */
public class ClientFrame extends JFrame {
    
    JTextField txtPort ;
    JTextField txtIP;
    JTextField txtCIP;//-----------------------------
    TextArea taR, taS;
    JButton bR, bS;
    JScrollPane p1, p2 ;
    Socket incoming;
    ObjectOutputStream oos ; // object output stream
    ObjectInputStream ois ; // object input stream
    Listener listen ;
    
    public ClientFrame() throws UnknownHostException {
        super("Chat Client");
        setDefaultLookAndFeelDecorated(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
        setSize(500,450);
        setVisible(true);
        getContentPane().setLayout(null);
        JLabel lblPort = new JLabel("Port Number [>1024]");
        JLabel lblSIP = new JLabel("SERVER IP");
        JLabel lblCIP = new JLabel("CLIENT IP");//----------------------------
        getContentPane().add(lblPort);
        getContentPane().add(lblSIP);
        getContentPane().add(lblCIP);//--------------------------------
        txtIP = new JTextField("127.0.0.1"); // specify the IP to connect 
        txtPort = new JTextField("5000"); // specify the port to connect
        txtCIP = new JTextField(getMyIP());//
        getContentPane().add(txtIP);
        getContentPane().add(txtPort);
        getContentPane().add(txtCIP);//--------------------------------------
        taR = new TextArea(); /* textbox to the left side */ 
        taS = new TextArea(); /* textbox to the right side where we enter the message */
        getContentPane().add(taR);
        getContentPane().add(taS);
        bS = new JButton("Go");
        getContentPane().add(bS);
        bR = new JButton("Connect");
        getContentPane().add(bR);
        lblSIP.setBounds(10,20,70,25);
        lblCIP.setBounds(10,50,70,25);
        lblPort.setBounds(190,20,140,25);
        txtIP.setBounds(75,20,90,25);
        txtCIP.setBounds(75,50,90,25);
        txtPort.setBounds(315,20,40,25);
        bR.setBounds(370,20,110,25);
        taR.setBounds(20,80,445,250);
        taS.setBounds(20,350,380,50);
        bS.setBounds(415,350,50,50);
        
        /******************************************
        * Connect button
        * Listen for an available server
        ******************************************/
        bR.addActionListener(
            new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    
                    int currPort = Integer.parseInt(txtPort.getText());
                    
                    if(bR.getText().equals("Connect") && !txtIP.getText().isEmpty() && !txtCIP.getText().isEmpty() && !txtPort.getText().isEmpty()){
                        try {
                            incoming = new Socket(txtIP.getText(), currPort);
                            oos = new ObjectOutputStream(incoming.getOutputStream());
                            oos.flush();
                            ois = new ObjectInputStream(incoming.getInputStream());
                            listen = new Listener (taR, ois, -1, txtIP.getText());
                            listen.start();
                            taR.setText("");
                            taR.append("Status: Connected | Server IP: " + txtIP.getText() + " | Server Port: " + currPort +"\n" );
                        
                            bR.setText("Disconnect");
                        } catch (Exception ex) {
                            System.out.println("Connection Error : " + ex);
                            JOptionPane.showMessageDialog(null, "Connection Error: Failed to Connect Server " , "Error!", JOptionPane.ERROR_MESSAGE);
                        }
                    } else if (bR.getText().equals("Disconnect")){
                        //oos.writeObject("Client (" + txtCIP.getText() + ") Connected" );
                        taR.append("Status: Disconnected | Server IP: " + txtIP.getText() + " | Server Port: " + currPort +"\n" );
                        listen.stop();
                        oos=null;
                        bR.setText("Connect");
                    } else {
                        JOptionPane.showMessageDialog(null, "Connection Failed: Server IP, Port, Client IP must be set " , "Warning!", JOptionPane.WARNING_MESSAGE);
                    }
                }
            }
        );

        /*****************************************************
        * Go button listener
        * If there is a connection (oos != null) 
        * send (write) message to the outputstream 
        *****************************************************/ 
        bS.addActionListener(
            new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    if (oos == null) {
                        return ;
                    } 
                    
                    try {
                        //oos.writeObject(taS.getText());
                        oos.writeObject("(" + txtCIP.getText() + "): " + taS.getText());
                    } catch (Exception ex) {
                        System.out.println("Go error : " + ex);
                    }
                    taS.setText(""); // After sending the text, empty the container
                }
            }
        );
        
        validate();
    }
    
    public String getMyIP() throws UnknownHostException{
        String myIP = Inet4Address.getLocalHost().getHostAddress();
        return myIP;
    }

    public static void main (String arg[]) throws UnknownHostException {
        new ClientFrame();
    }
   
}
