/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chatter;

import java.io.* ;
import java.awt.* ;

/**
 *
 * @author Keen
 */
public class Listener extends Thread {
    
    TextArea taR ;
    ObjectInputStream ois; 
    int id ; 
    String acctname; 
    ObjectOutputStream oos[]; 

    public Listener(TextArea taR, ObjectInputStream ois, int id, String acctname) {
        this.taR = taR;
        this.ois = ois ;
        this.id = id ;
        this.acctname = acctname;
    }
    
    public void run() {
        try {
            String msg ; 
            while (true) {
                msg = (String) ois.readObject();
                
                if (id < 0 ) {
                    taR.append(msg + "\n"); // a call from a client
                } else {
                    taR.append(msg + "\n");
                } 
                
                if ( oos != null) {
                    for (int a = 0 ; a < oos.length ; a++) {
                        if (oos[a] != null) oos[a].writeObject(msg);
                    }
                }
            }
        } catch (Exception ex) {
            System.out.println(" Listener Error : " + ex);
        }
    }
    
    public void setAll(ObjectOutputStream oos[]) {
        this.oos = oos ;
    }
}
