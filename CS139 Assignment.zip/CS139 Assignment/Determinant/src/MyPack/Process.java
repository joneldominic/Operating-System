/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MyPack;

/**
 *
 * @author DCST
 */
public class Process extends Thread{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        double det = 0.0;
        
        
        //Det = 8.0
        double [][] data={{3,2,1},
                         {4,2,2},
                         {1,-1,1}};
        
        
        DownwardMult dMult = new DownwardMult(data);
        UpwardMult uMult = new UpwardMult(data);
        
        Thread t1 = new Thread(dMult);
        Thread t2 = new Thread(uMult);
        
        t1.start();
        t2.start();
        
        try{
            t1.join();
            t2.join();
        }catch(InterruptedException e){
           e.printStackTrace();
        }        
        
        det = dMult.getSum() - uMult.getSum();
        System.out.println("Determinant = " + det);
    }
    
}
