/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MyPack;

/**
 *
 * @author DCST
 */
public class UpwardMult implements Runnable {
    
    private int dataSize = 0;
    private double [][] data;
    private double sum = 0.0;
    
    public UpwardMult(double [][] inData){
        setData(inData);
    }
        
    public void setData(double [][] inData){
        dataSize = inData.length;
        data = new double [dataSize][dataSize];
        
        for(int i=0; i<dataSize;i++){
            for(int j=0; j<dataSize;j++){
                data[i][j] = inData[i][j];
            }
        }
    }
    
    public double getSum(){
        return sum;
    }
    
    @Override
    public void run() {
        double product = 1.0;
        int col = 0;
        
        for(int c=0;c<dataSize;c++){
            product=1.0;
            col=c;
            for(int r=(dataSize-1);r>=0;r--){
                col%=dataSize;
                product*=data[r][col];
                col++;
            }
            sum+=product;
        }
    }
}
