/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package dphilosophers;

/**
 *
 * @author User
 */

public class Semaphore extends Object {
    private int count;   
    public Semaphore(int startingCount){
        count = startingCount;
    }   
    
    public void down(){
        synchronized (this) {          
            while (count <= 0) {
                try {
                    wait();  // We must wait
                } catch (InterruptedException ex) {
                    // I was interupted, continue onwards
                }
            }                
            count--; // We can decrement the count
        }                
    }   
    public void up(){
        synchronized (this) {
            count++;
            if (count == 1 ) {             
                notify(); //notify a waiting thread to wakeup
            }
        }
    }    
}
