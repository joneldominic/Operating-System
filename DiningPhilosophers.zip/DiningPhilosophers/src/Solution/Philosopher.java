/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Solution;

/**
 *
 * @author Tapang
 */
public class Philosopher implements Runnable {
    // The forks on either side of this Philosopher
    private Object leftFork;
    private Object rightFork;
     
    public Philosopher(Object leftFork, Object rightFork) {
        this.leftFork = leftFork;
        this.rightFork = rightFork;
    }
     
    private void eatOrThink(String action) throws InterruptedException {
        int sleeptime = ((int) (Math.random() * 1000));
        System.out.println(Thread.currentThread().getName() + action+ " " + "(" +sleeptime +"ms)" );
        Thread.sleep(sleeptime);
    }
    
    private void pickOrPutFork(String action) throws InterruptedException {
        int sleeptime = ((int) (Math.random() * 1000));
        System.out.println(Thread.currentThread().getName() + action);
        Thread.sleep(sleeptime);
    }
     
    @Override
    public void run() {
         try {
            while (true) {
                 
                // thinking
                eatOrThink(": Thinking");
                synchronized (leftFork) {
                    
                    pickOrPutFork(": Picked up left fork");
                    
                    synchronized (rightFork) {
                        
                        pickOrPutFork(": Picked up right fork"); 
                        
                        // eating
                        eatOrThink(": Eating");
                        
                        pickOrPutFork(": Put down right fork");
                    }
                     
                    // Back to thinking
                    pickOrPutFork(": Put down left fork");
                }
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return;
        }
    }
}
