/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package DiningPhilosopher;

/**
 *
 * @author room103
 */
public class Philosopher implements Runnable{
    // The forks on either side of this Philosopher 
    private Object leftFork;
    private Object rightFork;
 
    public Philosopher(Object leftFork, Object rightFork) {
        this.leftFork = leftFork;
        this.rightFork = rightFork;
    }
    
    private void doAction(String action) throws InterruptedException {
        int sleeptime = ((int) (Math.random() * 1000));
        System.out.println(Thread.currentThread().getName() + action +"("+sleeptime+"ms)");
        Thread.sleep(sleeptime);
    }
    
    private void forkAction(String action) throws InterruptedException {
        int sleeptime = ((int) (Math.random() * 1000));
        System.out.println(Thread.currentThread().getName() + action);
        Thread.sleep(sleeptime);
    }
    
    @Override
     public void run() {
        try {
            while (true) {
                 
                // Thinking
                doAction(": Thinking");
                synchronized (leftFork) {
                    forkAction(": Picked up left fork");
                    synchronized (rightFork) {
                        forkAction(": Picked up right fork"); 
                        // Eating
                        doAction(": Eating");
                        forkAction(": Put down right fork");
                    }
                     
                    // Back to thinking
                    forkAction(": Put down left fork");
                }
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return;
        }
    }
}
