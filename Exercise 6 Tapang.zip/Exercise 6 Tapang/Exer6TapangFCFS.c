#include <stdio.h>

struct process
{
    int procID;
    int burstTime;
    int waitTime;
    int turnTime;
};

void setBurstAndArrivTime(int numOfProcess, struct process pProcess[]);
void calcWaitTime(int numOfProcess, struct process pProcess[]);
void calcTurnATime(int numOfProcess, struct process pProcess[]);
int getAveWaitTime(int numOfProcess, struct process pProcess[]);
int getAveTurnATime(int numOfProcess, struct process pProcess[]);
void displayOuput(int numOfProcess, struct process pProcess[]);

int main()
{
    int time;
	int numOfProcess = 0;
    struct process pProcess[20];

    printf(" --------------------------------------------------------------\n");
    printf("|-------- First Come First Serve Scheduling Algorithm ---------|\n");
    printf(" --------------------------------------------------------------\n");
    printf("\n Enter total number of Process (Maximum of 20): ");
	scanf("%d", &numOfProcess);

	setBurstTime(numOfProcess, pProcess);
	calcWaitTime(numOfProcess, pProcess);
	calcTurnATime(numOfProcess, pProcess);
	displayOuput(numOfProcess, pProcess);

    return 0;
}

void setBurstTime(int numOfProcess, struct process pProcess[])
{
    int i; //loop counter

    printf("\n Enter Process Burst Time\n");
	printf(" --------------------------------------------------------------\n");
	for(i=0;i<numOfProcess;i++)
	{
		printf(" P[%d]: ", i+1);
        scanf("%d", &pProcess[i].burstTime);
        pProcess[i].procID = i+1;
        pProcess[i].turnTime = 0;
        pProcess[i].waitTime = 0;
	}
	printf(" --------------------------------------------------------------\n");
}

void calcWaitTime(int numOfProcess, struct process pProcess[])
{
    int i, j; //loop counters

	for(i=0;i<numOfProcess;i++)
	{
        pProcess[i].waitTime = 0;

		for(j=0;j<i;j++)
        {
            pProcess[i].waitTime += pProcess[j].burstTime;
        }
	}
}

void calcTurnATime(int numOfProcess, struct process pProcess[])
{
    int i; //loop counter

	for(i=0;i<numOfProcess;i++)
    {
        pProcess[i].turnTime = pProcess[i].burstTime + pProcess[i].waitTime;
    }
}

int getAveWaitTime(int numOfProcess, struct process pProcess[])
{
    int i; //loop counter
    int aveWT=0;

    for(i=0;i<numOfProcess;i++)
    {
        aveWT+=pProcess[i].waitTime;
    }

    aveWT /= numOfProcess;

    return aveWT;
}

int getAveTurnATime(int numOfProcess, struct process pProcess[])
{
    int i; //loop counter
    int aveTT=0;

    for(i=0;i<numOfProcess;i++)
    {
        aveTT+=pProcess[i].turnTime;
    }

    aveTT /= numOfProcess;

    return aveTT;
}

void displayOuput(int numOfProcess, struct process pProcess[])
{
    int j; //loop counter

    printf(" Process\tBurst Time\tWaiting Time\tTurnaround Time\n");
	printf(" --------------------------------------------------------------\n");
    for(j=0; j<numOfProcess; j++)
    {
        printf(" P[%d]\t\t%d\t\t%d\t\t%d\n", pProcess[j].procID, pProcess[j].burstTime, pProcess[j].waitTime,pProcess[j].turnTime);
    }
    printf(" --------------------------------------------------------------");
	printf("\n Average Waiting Time = %d\n", getAveWaitTime(numOfProcess,pProcess));
	printf(" Average Turnaround Time = %d\n", getAveTurnATime(numOfProcess,pProcess));
    printf(" --------------------------------------------------------------");

}
