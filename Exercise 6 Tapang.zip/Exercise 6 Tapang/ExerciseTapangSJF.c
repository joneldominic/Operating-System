#include <stdio.h>

struct process
{
    int procID;
    int burstTime;
    int waitTime;
    int turnTime;
};

void setBurstTime(int numOfProcess, struct process pProcess[]);
void sortBurstTimeAsc(int numOfProcess, struct process pProcess[]);
void calcWaitTime(int numOfProcess, struct process pProcess[]);
void calcTurnATime(int numOfProcess, struct process pProcess[]);
float getAveWaitTime(int numOfProcess, struct process pProcess[]);
float getAveTurnATime(int numOfProcess, struct process pProcess[]);
void displayOuput(int numOfProcess, struct process pProcess[]);

int main()
{
	int numOfProcess = 0;
    struct process pProcess[20];

    printf(" --------------------------------------------------------------\n");
    printf("|---------- Shortest Job First Scheduling Algorithm -----------|\n");
    printf(" --------------------------------------------------------------\n");
    printf("\n Enter total number of Process (Maximum of 20): ");
	scanf("%d", &numOfProcess);

	setBurstTime(numOfProcess, pProcess);
	sortBurstTimeAsc(numOfProcess, pProcess);
	calcWaitTime(numOfProcess, pProcess);
	calcTurnATime(numOfProcess, pProcess);
	displayOuput(numOfProcess, pProcess);

    return 0;
}

void setBurstTime(int numOfProcess, struct process pProcess[])
{
    int i; //loop counter

    printf("\n Enter Process Burst Time\n");
	printf(" --------------------------------------------------------------\n");
	for(i=0;i<numOfProcess;i++)
	{
		printf(" P[%d]: ", i+1);
        scanf("%d", &pProcess[i].burstTime);
        pProcess[i].procID = i+1;
        pProcess[i].turnTime = 0;
        pProcess[i].waitTime = 0;
	}
	printf(" --------------------------------------------------------------\n");
}

void sortBurstTimeAsc(int numOfProcess, struct process pProcess[])
{
    //Selection Sort

    int i, j; //loop counters
    int pos;
    struct process tempProcess;

    for(i=0;i<numOfProcess;i++)
    {
        pos=i;

        for(j=i+1;j<numOfProcess;j++)
        {
            if(pProcess[j].burstTime<pProcess[pos].burstTime)
            {
                pos=j;
            }
        }
        tempProcess = pProcess[i];
        pProcess[i] = pProcess[pos];
        pProcess[pos] = tempProcess;
    }
}

void calcWaitTime(int numOfProcess, struct process pProcess[])
{
    int i, j; //loop counters

	for(i=0;i<numOfProcess;i++)
	{
        pProcess[i].waitTime = 0;

		for(j=0;j<i;j++)
        {
            pProcess[i].waitTime += pProcess[j].burstTime;
        }
	}
}

void calcTurnATime(int numOfProcess, struct process pProcess[])
{
    int i; //loop counter

	for(i=0;i<numOfProcess;i++)
    {
        pProcess[i].turnTime = pProcess[i].burstTime + pProcess[i].waitTime;
    }
}

float getAveWaitTime(int numOfProcess, struct process pProcess[])
{
    float aveWT=0;
    int i; //loop counter

    for(i=0;i<numOfProcess;i++)
    {
        aveWT+=pProcess[i].waitTime;
    }

    aveWT /= numOfProcess;

    return aveWT;
}

float getAveTurnATime(int numOfProcess, struct process pProcess[])
{
    float aveTT=0;
    int i; //loop counter

    for(i=0;i<numOfProcess;i++)
    {
        aveTT+=pProcess[i].turnTime;
    }

    aveTT /= numOfProcess;

    return aveTT;
}

void displayOuput(int numOfProcess, struct process pProcess[])
{
    int j; //loop counter

    printf(" Process\tBurst Time\tWaiting Time\tTurnaround Time\n");
	printf(" --------------------------------------------------------------\n");
    for(j=0; j<numOfProcess; j++)
    {
        printf(" P[%d]\t\t%d\t\t%d\t\t%d\n", pProcess[j].procID, pProcess[j].burstTime, pProcess[j].waitTime,pProcess[j].turnTime);
    }
    printf(" --------------------------------------------------------------");
	printf("\n Average Waiting Time = %f\n", getAveWaitTime(numOfProcess,pProcess));
	printf(" Average Turnaround Time = %f\n", getAveTurnATime(numOfProcess,pProcess));
    printf(" --------------------------------------------------------------");

}
