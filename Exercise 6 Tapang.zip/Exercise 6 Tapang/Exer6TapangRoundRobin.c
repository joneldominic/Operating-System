//Jonel Dominic E. Tapang
#include<stdio.h>

int main()
{
    int count,j,n,time,remain,time_quantum,flag=0;
    int wait_time=0,turnaround_time=0,at[10],bt[10],rt[10];

    printf(" --------------------------------------------------------------\n");
    printf("|------------- Round Robin Scheduling Algorithm ---------------|\n");
    printf(" --------------------------------------------------------------\n");
    printf("\n Enter total number of Process (Maximum of 20): ");
    scanf("%d",&n);
    remain=n;

    printf(" Enter Process Burst Time\n");
	printf(" --------------------------------------------------------------\n\n");
	for(count=0;count<n;count++)
	{
		printf(" P[%d]\n", count+1);
		printf(" Arrival Time:\t");
        scanf("%d",&at[count]);
        printf(" Burst Time:\t");
        scanf("%d",&bt[count]);
        rt[count]=bt[count];
        printf("\n");
	}
	printf(" --------------------------------------------------------------\n");
    printf(" Enter Time Quantum: ");
	scanf("%d",&time_quantum);
	printf(" --------------------------------------------------------------\n");

    printf(" Process|Turnaround Time|Waiting Time\n\n");
    for(time=0,count=0;remain!=0;)
    {
        if(rt[count]<=time_quantum && rt[count]>0)
        {
            time+=rt[count];
            rt[count]=0;
            flag=1;
        }
        else if(rt[count]>0)
        {
            rt[count]-=time_quantum;
            time+=time_quantum;
        }

        if(rt[count]==0 && flag==1)
        {
            remain--;
            printf(" P[%d]\t|\t%d\t|\t%d\n",count+1,time-at[count],time-at[count]-bt[count]);
            wait_time+=time-at[count]-bt[count];
            turnaround_time+=time-at[count];
            flag=0;
        }

        if(count==n-1)
        {
            count=0;
        }
        else if(at[count+1]<=time)
        {
            count++;
        }
        else
        {
            count=0;
        }
    }

    printf(" --------------------------------------------------------------\n");
    printf(" Average Waiting Time= %f\n",wait_time*1.0/n);
    printf(" Avg Turnaround Time = %f",turnaround_time*1.0/n);
    printf("\n --------------------------------------------------------------\n");

    return 0;
}
